// This first exercise changes only the heading in index.html.
// No JavaScript change is needed.
