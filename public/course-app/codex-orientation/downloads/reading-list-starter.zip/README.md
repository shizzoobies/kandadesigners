# Your first steps with Codex: practice folder

This folder accompanies the K & A Performance Codex desktop orientation.
Keep an untouched copy of the ZIP so you can start again.

Unpack the ZIP into a folder called reading-list-starter. On Windows,
right-click and choose Extract All. On a Mac, double-click the ZIP.
Keep index.html, styles.css, app.js, and this README together.

Open index.html in your browser. If it opens in an editor, right-click it
and use Open with to choose a browser. You should see Weekend reading
and three books. Opening this file does not publish it online.

Follow the current official desktop quickstart to install and sign in:
https://learn.chatgpt.com/docs/quickstart
Your account and app access are separate from this training.

Open the extracted folder as a local project in Codex. Start a task there.
Ask: Explain this practice project in everyday language. Do not change
any files yet.

Then ask: Change the heading from Weekend reading to My reading list.
Keep the three books and the design the same. Explain which file you
changed and how to check the result.

Open or refresh index.html in your browser. Check the heading and confirm
that the same three books and the design remain. Read Codex's summary.

index.html holds the page. styles.css controls its appearance. app.js
is reserved for page behavior. README.md is this note.

More training: https://ka-performancefl.com/training/ai/
