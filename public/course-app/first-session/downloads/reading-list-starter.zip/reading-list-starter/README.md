# Reading list starter

This is the deliberately unfinished practice project for K & A Performance's first Claude Code lesson.

1. Extract this ZIP into a folder you recognize.
2. Open index.html in a browser to see the starting point.
3. Open a terminal in this folder and run claude.
4. Ask Claude to inspect the files and plan the smallest JavaScript change to remember checked book IDs after refresh.
5. Review the plan, then allow the implementation.
6. Check a book, reload, clear it, and reload again. Check that each book is independent.

No packages, build step, test command, database, or account are required by this project. Claude Code itself needs a supported sign-in method.
If local-file storage is restricted by your browser, ask Claude to serve this folder locally. Use the same URL for each check.
Optional next task: show an unread-book count.
