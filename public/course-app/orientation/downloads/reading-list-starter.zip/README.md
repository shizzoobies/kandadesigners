# Orientation practice: your reading list

This folder accompanies Before Your First Build from K & A Performance.

Extract the ZIP first. Windows: right-click the ZIP and choose Extract All.
Mac: double-click the ZIP. Open the resulting reading-list-starter folder.
The four files should be directly inside it.

Open index.html in your browser. If it opens in an editor, right-click it
and use Open with to choose your browser. Look for the Weekend reading
heading and the three books. This page is on your computer, not published.

The orientation rehearses changing the heading to My reading list while
keeping the same books and design. Complete that rehearsal in the lesson.
You do not need to install Claude Code or edit these files yet.

index.html holds the page. styles.css controls its appearance. app.js
provides its behavior. README.md is this note.

When you are ready for installation and real edits, continue to Your first
session: https://ka-performancefl.com/course/
That lesson supplies its own starter and teaches remembering checked books
after a refresh. Claude Code requires a supported account separately.

Orientation: https://ka-performancefl.com/course/orientation/
