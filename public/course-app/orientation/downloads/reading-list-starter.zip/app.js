// The browser currently forgets checkbox selections after a refresh.
// First task for Claude Code: save checked book IDs and restore them on load.
// Keep index.html and styles.css as they are.
